package com.example.gps;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.widget.Toast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Random;

public class CallReceiver extends BroadcastReceiver {

    private static boolean callEnded = false;
    double minLat = -90.0;
    double maxLat = 90.0;
    double minLon = -180.0;
    double maxLon = 180.0;


    private MainActivity mainActivity;

    public void setMainActivity(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (action != null && action.equals("android.intent.action.PHONE_STATE")) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

            if (state != null && state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
                String savedPhoneNumber = getSavedPhoneNumber(context);

                if (savedPhoneNumber.equals(incomingNumber)) {
                    showToast(context, "Llamada entrante"); // Mostrar mensaje de llamada entrante
                    callEnded = false;
                }
            }

            if (state != null && state.equals(TelephonyManager.EXTRA_STATE_IDLE) && !callEnded) {
                showToast(context, "Llamada finalizada");
                callEnded = true;
                sendLocationSMS(context);
            }
        }
    }

    private void showToast(Context context, String message) {
        if (mainActivity != null) {
            mainActivity.showToastMessage(message);
        }
    }

    private String getSavedPhoneNumber(Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getString("phoneNumber", "");
    }

    private void hacerLlamada(Context context, String phoneNumber) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // El permiso no está concedido, solicítalo
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.CALL_PHONE}, 1);
            return;
        }
        if (!TextUtils.isEmpty(phoneNumber)) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + phoneNumber));
            callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(context, MyDeviceAdmin.class);

            // Verificar si el administrador de políticas de dispositivo está activado
            if (devicePolicyManager.isAdminActive(adminComponent)) {
                showToast(context,"permisos de administrador");
                // Apagar la pantalla
                devicePolicyManager.lockNow();
            } else {
                ComponentName adminComponentName = new ComponentName(context, MyDeviceAdmin.class);
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponentName);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Se requieren permisos de administrador para apagar la pantalla");
                context.startActivity(intent);

            }
            AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            boolean isSpeakerphoneOn = false;
            try {

                if (audioManager != null) {
                    // Guardar el estado actual del altavoz
                    isSpeakerphoneOn = audioManager.isSpeakerphoneOn();
                    // Desactivar el altavoz
                    audioManager.setSpeakerphoneOn(false);
                } else {
                    //Toast.makeText(context, "No se pudo acceder al servicio de audio", Toast.LENGTH_SHORT).show();
                }
                    context.startActivity(callIntent);
                if (devicePolicyManager.isAdminActive(adminComponent)) {
                    showToast(context,"permisos de administrador");
                    // Apagar la pantalla
                    devicePolicyManager.lockNow();
                }
                Toast.makeText(context, "Llamada realizada correctamente", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(context, "Error al realizar la llamada", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
            audioManager.setSpeakerphoneOn(isSpeakerphoneOn);

        } else {
            Toast.makeText(context, "Ingrese un número de teléfono", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendLocationSMS(Context context) {
                        //double latitude2 = generateRandomLatitude(minLat, maxLat);
                       // double longitude3 = generateRandomLongitude(minLon, maxLon);
        //   String message = "Mi ubicación actual es: Latitud: " + latitude2 + ", Longitud: " + longitude3;
        String phoneNumber = getSavedPhoneNumber(context);
        try {
            double latitude2 = generateRandomLatitude(minLat, maxLat);
            double longitude3 = generateRandomLongitude(minLon, maxLon);
            String message = "Mi ubicación actual es: Latitud: " + latitude2 + ", Longitud: " + longitude3;
                        showToast(context, "Numero" + phoneNumber);
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                        showToast(context, "Mensaje enviado con la geolocalización"+message );
        } catch (Exception e) {
            showToast(context, "Error al enviar el mensaje SMS" + e.toString());
        }
                        // Realizar la llamada después de enviar el mensaje
                        hacerLlamada(context, phoneNumber);
    }
    private static double generateRandomLatitude(double minLat, double maxLat) {
        Random random = new Random();
        return minLat + (maxLat - minLat) * random.nextDouble();
    }

    private static double generateRandomLongitude(double minLon, double maxLon) {
        Random random = new Random();
        return minLon + (maxLon - minLon) * random.nextDouble();
    }

}